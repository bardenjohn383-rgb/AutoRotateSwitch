#!/system/bin/sh
DATA=/data/adb/codev_autorotate
MOD=/data/adb/modules/codev_autorotate
LOG=$DATA/run.log
WDPID=$DATA/watchdog.pid
mkdir -p "$DATA"
if [ -f "$WDPID" ]; then
  old=$(cat "$WDPID" 2>/dev/null)
  if [ -n "$old" ] && [ "$old" != "$$" ] && kill -0 "$old" 2>/dev/null; then
    cmd=$(tr '\000' ' ' < "/proc/$old/cmdline" 2>/dev/null)
    case "$cmd" in *codev_autorotate/watchdog.sh*) exit 0 ;; esac
  fi
fi
echo $$ > "$WDPID"
trap 'rm -f "$WDPID"' EXIT INT TERM HUP
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 5; done
while true; do
  now=$(date +%s)
  pid=$(cat "$DATA/service.pid" 2>/dev/null)
  running=0
  if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
    cmd=$(tr '\000' ' ' < "/proc/$pid/cmdline" 2>/dev/null)
    case "$cmd" in *codev_autorotate/service.sh*) running=1 ;; esac
  fi
  hb=$(cat "$DATA/heartbeat" 2>/dev/null)
  interval=$(sed -n 's/^INTERVAL=\([0-9][0-9]*\)$/\1/p' "$DATA/config.sh" 2>/dev/null | head -n 1)
  case "$interval" in ''|*[!0-9]*) interval=5 ;; esac
  limit=$((interval * 4 + 25)); [ "$limit" -lt 45 ] && limit=45
  age=$((now - ${hb:-0}))
  if [ "$running" != "1" ] || [ "$age" -gt "$limit" ]; then
    [ "$running" = "1" ] && kill -9 "$pid" 2>/dev/null
    echo "$(date '+%F %T') [看门狗] 服务异常，尝试恢复" >> "$LOG"
    rm -f "$DATA/service.pid"
    ( nohup sh "$MOD/service.sh" fast >/dev/null 2>&1 </dev/null & )
    sleep 3
  fi
  sleep 12
done
