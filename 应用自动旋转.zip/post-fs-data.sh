#!/system/bin/sh
# 尽早启动独立看门狗；它会等待系统启动完成后再检查服务。
( nohup sh /data/adb/modules/codev_autorotate/watchdog.sh >/dev/null 2>&1 </dev/null & )
exit 0
