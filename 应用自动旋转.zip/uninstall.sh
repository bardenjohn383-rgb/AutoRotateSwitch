#!/system/bin/sh
DATA=/data/adb/codev_autorotate
# 停止看门狗和主服务，避免卸载后残留进程继续改动网络。
wpid=$(cat "$DATA/watchdog.pid" 2>/dev/null)
spid=$(cat "$DATA/service.pid" 2>/dev/null)
[ -n "$wpid" ] && kill "$wpid" 2>/dev/null
[ -n "$spid" ] && kill "$spid" 2>/dev/null
sleep 1
[ -n "$wpid" ] && kill -9 "$wpid" 2>/dev/null
[ -n "$spid" ] && kill -9 "$spid" 2>/dev/null
rm -rf "$DATA"
