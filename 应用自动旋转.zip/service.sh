#!/system/bin/sh
DATA=/data/adb/codev_autorotate
CFG=$DATA/config.sh
APPS=$DATA/apps.conf
LOG=$DATA/run.log
ST=$DATA/state
PID=$DATA/service.pid
HB=$DATA/heartbeat
ACTIVE_FILE=$DATA/active.conf
mkdir -p "$DATA"

[ -f "$CFG" ] || cat > "$CFG" <<'CFGEOF'
ENABLED=1
PKGS=com.tencent.tmgp.codev
INTERVAL=5
ENTER_ROTATE_ON=1
EXIT_ROTATE_OFF=1
LOG_MAX_KB=200
CFGEOF

log() { echo "$(date '+%F %T') [服务] $*" >> "$LOG"; }

# 避免重复启动；只在记录 PID 确实对应本服务时退出。
if [ -f "$PID" ]; then
  oldpid=$(cat "$PID" 2>/dev/null)
  if [ -n "$oldpid" ] && [ "$oldpid" != "$$" ] && kill -0 "$oldpid" 2>/dev/null; then
    oldcmd=$(tr '\000' ' ' < "/proc/$oldpid/cmdline" 2>/dev/null)
    case "$oldcmd" in *codev_autorotate/service.sh*) exit 0 ;; esac
  fi
fi

echo $$ > "$PID"
cleanup() {
  rm -f "$PID"
}
trap cleanup EXIT INT TERM HUP

until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 5; done
[ "$1" = "fast" ] || sleep 10
log "服务启动 (pid $$)"

NL='
'
ACTIVE=""
if [ -f "$ACTIVE_FILE" ]; then
  candidate=$(cat "$ACTIVE_FILE" 2>/dev/null)
  case "$candidate" in *[!A-Za-z0-9_.,]*) candidate="" ;; esac
  ACTIVE="$candidate"
fi
DEAD=""
prevfg=""
failn=0

save_active() {
  tmp="$ACTIVE_FILE.tmp"
  printf '%s' "$ACTIVE" > "$tmp" && mv "$tmp" "$ACTIVE_FILE"
}

pkgs_of() {
  sed -n -e 's/.* u[0-9][0-9]* \([A-Za-z0-9_.][A-Za-z0-9_.]*\)\/.*/\1/p' \
         -e 's/^ *ACTIVITY \([A-Za-z0-9_.][A-Za-z0-9_.]*\)\/.*/\1/p'
}

get_top() {
  TOPPKG=""; ALLTOP=""
  out=$(dumpsys activity activities 2>/dev/null)
  ALLTOP=$(echo "$out" | grep "topResumedActivity" | pkgs_of)
  if [ -z "$ALLTOP" ]; then ALLTOP=$(echo "$out" | grep "ResumedActivity" | grep -v -i "last" | pkgs_of); fi
  if [ -z "$ALLTOP" ]; then ALLTOP=$(dumpsys window 2>/dev/null | grep -E "mCurrentFocus|mFocusedApp|mFocusedWindow" | pkgs_of); fi
  if [ -z "$ALLTOP" ]; then ALLTOP=$(dumpsys activity top 2>/dev/null | grep "ACTIVITY" | pkgs_of); fi
  TOPPKG=$(echo "$ALLTOP" | head -n 1)
  out=""
}

find_fg() {
  FG=""
  get_top
  echo "$TOPPKG" > "$DATA/fg_now"
  [ -z "$PKGS" ] && return
  [ -z "$ALLTOP" ] && return
  OLDIFS=$IFS; IFS=,
  for p in $PKGS; do
    case "$NL$ALLTOP$NL" in *"$NL$p$NL"*) FG=$p; break ;; esac
  done
  IFS=$OLDIFS
}

alive() {
  [ -n "$(pidof "$1" 2>/dev/null)" ] && return 0
  ps -A -o NAME 2>/dev/null | awk -v p="$1" '$0==p || index($0,p ":")==1 {found=1} END{exit !found}'
}
in_top() { case "$NL$ALLTOP$NL" in *"$NL$1$NL"*) return 0 ;; esac; return 1; }
in_active() { case "$ACTIVE" in *",$1,"*) return 0 ;; esac; return 1; }
add_active() { [ -z "$ACTIVE" ] && ACTIVE=","; ACTIVE="$ACTIVE$1,"; save_active; }
rm_active() {
  pre=${ACTIVE%%",$1,"*}; post=${ACTIVE#*",$1,"}
  ACTIVE="$pre,$post"
  case "$ACTIVE" in ,|,,) ACTIVE="" ;; esac
  save_active
}
in_dead() { case "$DEAD" in *",$1,"*) return 0 ;; esac; return 1; }
add_dead() { [ -z "$DEAD" ] && DEAD=","; DEAD="$DEAD$1,"; }
rm_dead() {
  pre=${DEAD%%",$1,"*}; post=${DEAD#*",$1,"}
  DEAD="$pre,$post"
  case "$DEAD" in ,|,,) DEAD="" ;; esac
}
in_pkgs() { case ",$PKGS," in *",$1,"*) return 0 ;; esac; return 1; }

load_app_opts() {
  AEN=$ENTER_ROTATE_ON; AXF=$EXIT_ROTATE_OFF
  [ -f "$APPS" ] || return
  while IFS='|' read -r a b c; do
    if [ "$a" = "$1" ]; then
      case "$b" in 0|1) AEN=$b ;; esac
      case "$c" in 0|1) AXF=$c ;; esac
      break
    fi
  done < "$APPS"
}
do_enter() {
  load_app_opts "$1"
  if [ "$AEN" = "1" ]; then settings put system accelerometer_rotation 1 && log "  自动旋转已开启"; fi
}
do_exit() {
  load_app_opts "$1"
  # 同时回到竖屏，避免在横屏状态下关闭自动旋转后桌面被锁成横屏
  if [ "$AXF" = "1" ]; then settings put system accelerometer_rotation 0 && settings put system user_rotation 0 && log "  自动旋转已关闭"; fi
}

while true; do
  ENABLED=1; PKGS=""; INTERVAL=5
  ENTER_ROTATE_ON=1; EXIT_ROTATE_OFF=1; LOG_MAX_KB=200
  . "$CFG" 2>/dev/null
  case "$INTERVAL" in ''|*[!0-9]*) INTERVAL=5 ;; esac
  [ "$INTERVAL" -lt 1 ] && INTERVAL=5
  case "$LOG_MAX_KB" in ''|*[!0-9]*) LOG_MAX_KB=200 ;; esac

  date +%s > "$HB"
  if [ "$ENABLED" != "1" ]; then
    # 禁用时先按最后一个活动应用的退出规则恢复网络，再清除持久状态。
    if [ -n "$ACTIVE" ]; then
      last=${ACTIVE%,}; last=${last##*,}
      [ -n "$last" ] && do_exit "$last"
      log "自动旋转已暂停，已处理活动应用的恢复"
    fi
    echo off > "$ST"; : > "$DATA/fg_now"
    ACTIVE=""; DEAD=""; prevfg=""; save_active
  else
    find_fg
    if [ -z "$TOPPKG" ]; then
      failn=$((failn + 1))
      if [ "$failn" = "3" ]; then log "无法识别前台应用（dumpsys 没有可用输出），自动旋转开关可能失效"; fi
    else
      if [ "$failn" -ge 3 ]; then log "前台应用识别已恢复"; fi
      failn=0
    fi

    if [ -n "$FG" ] && ! in_active "$FG"; then
      log "进入 $FG"; do_enter "$FG"; add_active "$FG"
    fi

    OLDIFS=$IFS; IFS=,; set -- $ACTIVE; IFS=$OLDIFS
    for p in "$@"; do
      [ -z "$p" ] && continue
      reason=""
      if ! in_pkgs "$p"; then reason="已从监控列表移除"
      elif in_top "$p" || alive "$p"; then
        if in_dead "$p"; then rm_dead "$p"; fi
      elif in_dead "$p"; then reason="已关闭后台"
      else add_dead "$p"
      fi
      if [ -n "$reason" ]; then
        if in_dead "$p"; then rm_dead "$p"; fi
        rm_active "$p"
        if [ -z "$ACTIVE" ]; then log "退出 $p ($reason)"; do_exit "$p"
        else log "$p 已结束 ($reason)，仍有其他应用在运行，暂不关闭自动旋转"; fi
      fi
    done

    if [ -n "$FG" ]; then echo "fg $FG" > "$ST"
    elif [ -n "$ACTIVE" ]; then
      first=${ACTIVE#,}; first=${first%%,*}; echo "bgrun $first" > "$ST"
      [ -n "$prevfg" ] && log "$prevfg 切到后台，保持当前状态，关闭后台后再恢复"
    else echo bg > "$ST"; fi
    prevfg=$FG
  fi

  if [ -f "$LOG" ] && [ "$(wc -c < "$LOG")" -gt $((LOG_MAX_KB * 1024)) ]; then
    tail -n 300 "$LOG" > "$LOG.tmp" && mv "$LOG.tmp" "$LOG"
  fi
  sleep "$INTERVAL"
done
