SKIPUNZIP=0
mkdir -p /data/adb/codev_autorotate
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/watchdog.sh 0 0 0755
set_perm $MODPATH/post-fs-data.sh 0 0 0755
set_perm $MODPATH/uninstall.sh 0 0 0755
ui_print "- 安装完成，重启后生效"
ui_print "- 在模块列表点本模块的“打开”进入设置页（需支持 WebUI 的管理器）"
ui_print "- 在“应用”页添加需要自动开启旋转的应用"
